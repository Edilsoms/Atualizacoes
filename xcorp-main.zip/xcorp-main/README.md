# Twitter Clone Side Navigation FMX (Firemonkey)
I've created a clone of Twitter's side navigation bar with TRectangle and Animatefloat
you can change and use this in your project

https://github.com/yordanhutama/xcorp/assets/61320732/5a81f1bb-9c29-4f1d-9aa8-55b7ec8b69d6

next i will add white mode
